{-# OPTIONS_GHC -fwarn-incomplete-patterns -fwarn-unused-matches #-}
module PicoBlaze where

import Test.QuickCheck
import Control.Applicative
import Data.Bits
import Control.Monad.Resumption.Reactive
import Control.Monad.State
import Control.Monad.Identity

data W18 = W18 Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit deriving (Eq,Ord)
data W10 = W10 Bit Bit Bit Bit Bit Bit Bit Bit Bit Bit deriving (Eq,Ord,Show)
data W8 = W8 Bit Bit Bit Bit Bit Bit Bit Bit deriving (Eq,Ord,Show)
data W6 = W6 Bit Bit Bit Bit Bit Bit deriving (Eq,Ord,Show)
data W5 = W5 Bit Bit Bit Bit Bit deriving (Eq,Ord,Show)
data W4 = W4 Bit Bit Bit Bit deriving (Eq,Ord,Show)
data Bit = Zero | One deriving (Eq,Ord)

data Inputs = Inputs { instruction_in :: W18,
                       in_port_in     :: W8,
                       interrupt_in   :: Bit,
                       reset_in       :: Bit,

                       reg_data_in    :: W8,
                       reg_data2_in   :: W8,
                       stk_data_in    :: W10,
                       sp_data_in     :: W8 }
              deriving (Eq,Show)

data Outputs = Outputs { address_out       :: W10,
                         port_id_out       :: W8,
                         write_strobe_out  :: Bit,
                         out_port_out      :: W8,
                         read_strobe_out   :: Bit,
                         interrupt_ack_out :: Bit,
                         
                         reg_data_out      :: W8,
                         reg_addr_out      :: W4,
                         reg_addr2_out      :: W4,
                         reg_write_out     :: Bit,

                         stk_data_out      :: W10,
                         stk_addr_out      :: W5,
                         stk_write_out     :: Bit,

                         sp_data_out       :: W8,
                         sp_addr_out       :: W6,
                         sp_write_out      :: Bit }
               deriving (Eq,Show)

data CPUState = CPUState { pc     :: W10,
                           sp     :: W5,
                           zFlag  :: Bit,
                           cFlag  :: Bit,
                           ieFlag :: Bit,
                           
                           zSave  :: Bit,
                           cSave  :: Bit }
                deriving (Eq,Show)

type CPUM = ReacT Inputs Outputs (StateT CPUState Identity)

----------------------------
----------------------------
---                      ---
--- Instruction decoding ---
---                      ---
----------------------------
----------------------------

------------------------------------
-- Types for decoded instructions --
------------------------------------
type IWord = W18
type Reg = W4
-- The "Bit" fields for AddOp and SubOp indicate "with carry" (1) or not (0).
data Binop = AddOp Bit | AndOp | CompareOp | LoadOp | OrOp | SubOp Bit | TestOp
           | XorOp | RlOp | RrOp | Sl0Op | Sl1Op | SlaOp | SlxOp | Sr0Op
           | Sr1Op | SraOp | SrxOp deriving (Eq,Show)
data Operand = ConstOperand W8 | RegOperand Reg deriving (Eq,Show)
data BranchCond = NoCond | CCond | NCCond | ZCond | NZCond deriving (Eq,Show)
data Instruction = BinopInstr Binop Reg Operand
                 | BranchInstr Bit BranchCond W10  -- for the bit, 0=call and 1=jump
                 | ReturnInstr BranchCond
                 | ReturniInstr Bit                -- bit is whether to enable or disable interrupts
                 | IEnableInstr Bit                -- bit is whether to enable or disable interrupts
                 | FetchInstr Reg Operand
                 | StoreInstr Reg Operand
                 | InputInstr Reg Operand
                 | OutputInstr Reg Operand
                 | InvalidInstr
                 deriving (Eq,Show)

--
-- Begin stuff that should be implemented in VHDL
--
addCBit :: Bit -> Bit -> Bit -> (Bit,Bit)
addCBit 0 0 0 = (0,0)
addCBit 0 0 1 = (0,1)
addCBit 0 1 0 = (0,1)
addCBit 0 1 1 = (1,0)
addCBit 1 0 0 = (0,1)
addCBit 1 0 1 = (1,0)
addCBit 1 1 0 = (1,0)
addCBit _ _ _ = (1,1)

addCW8 :: W8 -> W8 -> Bit -> (Bit,W8)
addCW8 (W8 a7 a6 a5 a4 a3 a2 a1 a0) (W8 b7 b6 b5 b4 b3 b2 b1 b0) c_in =
  (c_out,W8 z7 z6 z5 z4 z3 z2 z1 z0)
  where
    (c0,z0) = addCBit a0 b0 c_in
    (c1,z1) = addCBit a1 b1 c0
    (c2,z2) = addCBit a2 b2 c1
    (c3,z3) = addCBit a3 b3 c2
    (c4,z4) = addCBit a4 b4 c3
    (c5,z5) = addCBit a5 b5 c4
    (c6,z6) = addCBit a6 b6 c5
    (c7,z7) = addCBit a7 b7 c6
    c_out = c7

subCBit :: Bit -> Bit -> Bit -> (Bit,Bit)
subCBit 0 0 0 = (0,0)
subCBit 0 0 1 = (1,1)
subCBit 0 1 0 = (1,1)
subCBit 0 1 1 = (1,0)
subCBit 1 0 0 = (0,1)
subCBit 1 0 1 = (0,0)
subCBit 1 1 0 = (0,0)
subCBit _ _ _ = (1,1)

subCW8 :: W8 -> W8 -> Bit -> (Bit,W8)
subCW8 (W8 a7 a6 a5 a4 a3 a2 a1 a0) (W8 b7 b6 b5 b4 b3 b2 b1 b0) c_in =
  (c_out,W8 z7 z6 z5 z4 z3 z2 z1 z0)
  where
    (c0,z0) = subCBit a0 b0 c_in
    (c1,z1) = subCBit a1 b1 c0
    (c2,z2) = subCBit a2 b2 c1
    (c3,z3) = subCBit a3 b3 c2
    (c4,z4) = subCBit a4 b4 c3
    (c5,z5) = subCBit a5 b5 c4
    (c6,z6) = subCBit a6 b6 c5
    (c7,z7) = subCBit a7 b7 c6
    c_out = c7

andW8 :: W8 -> W8 -> W8
andW8 (W8 a7 a6 a5 a4 a3 a2 a1 a0) (W8 b7 b6 b5 b4 b3 b2 b1 b0) =
  W8 z7 z6 z5 z4 z3 z2 z1 z0
  where
    z0 = andBit a0 b0
    z1 = andBit a1 b1
    z2 = andBit a2 b2
    z3 = andBit a3 b3
    z4 = andBit a4 b4
    z5 = andBit a5 b5
    z6 = andBit a6 b6
    z7 = andBit a7 b7

orW8 :: W8 -> W8 -> W8
orW8 (W8 a7 a6 a5 a4 a3 a2 a1 a0) (W8 b7 b6 b5 b4 b3 b2 b1 b0) =
  W8 z7 z6 z5 z4 z3 z2 z1 z0
  where
    z0 = orBit a0 b0
    z1 = orBit a1 b1
    z2 = orBit a2 b2
    z3 = orBit a3 b3
    z4 = orBit a4 b4
    z5 = orBit a5 b5
    z6 = orBit a6 b6
    z7 = orBit a7 b7

xorW8 :: W8 -> W8 -> W8
xorW8 (W8 a7 a6 a5 a4 a3 a2 a1 a0) (W8 b7 b6 b5 b4 b3 b2 b1 b0) =
  W8 z7 z6 z5 z4 z3 z2 z1 z0
  where
    z0 = xorBit a0 b0
    z1 = xorBit a1 b1
    z2 = xorBit a2 b2
    z3 = xorBit a3 b3
    z4 = xorBit a4 b4
    z5 = xorBit a5 b5
    z6 = xorBit a6 b6
    z7 = xorBit a7 b7

oddParity :: W8 -> Bit
oddParity (W8 a7 a6 a5 a4 a3 a2 a1 a0) =
  a0 `xorBit` a1
     `xorBit` a2
     `xorBit` a3
     `xorBit` a4
     `xorBit` a5
     `xorBit` a6
     `xorBit` a7

shlW8 :: W8 -> Bit -> W8
shlW8 (W8 _ b7 b6 b5 b4 b3 b2 b1) b0 = W8 b7 b6 b5 b4 b3 b2 b1 b0

shrW8 :: Bit -> W8 -> W8
shrW8 b7 (W8 b6 b5 b4 b3 b2 b1 b0 _) = W8 b7 b6 b5 b4 b3 b2 b1 b0

msbW8 :: W8 -> Bit
msbW8 (W8 b _ _ _ _ _ _ _) = b

lsbW8 :: W8 -> Bit
lsbW8 (W8 _ _ _ _ _ _ _ b) = b
--
-- End stuff that should be implemented in VHDL
--

doBinop :: Binop -> W8 -> W8 -> Bit -> Bit -> (W8,Bit,Bit)
doBinop o x y z_in c_in = case o of
                            AddOp wc  -> let (c_out,result) = addCW8 x y (andBit wc c_in)
                                             z_out          = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            AndOp     -> let result = andW8 x y
                                             z_out          = if result==0 then 1 else 0
                                         in (result,z_out,0)
                            CompareOp -> let z_out = if x==y then 1 else 0
                                             c_out = if x<y then 1 else 0
                                         in (x,z_out,c_out)
                            LoadOp    -> (y,z_in,c_in)
                            OrOp      -> let result = orW8 x y
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,0)
                            SubOp wc  -> let (c_out,result) = subCW8 x y (andBit wc c_in)
                                             z_out          = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            TestOp    -> let z_out = if x==y then 1 else 0
                                             c_out = oddParity (andW8 x y)
                                         in (x,z_out,c_out)
                            XorOp     -> let result = xorW8 x y
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,0)
                            RlOp      -> let c_out  = msbW8 x
                                             result = shlW8 x c_out
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            RrOp      -> let c_out  = lsbW8 x
                                             result = shrW8 c_out x
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            Sl0Op     -> let c_out  = msbW8 x
                                             result = shlW8 x 0
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            Sl1Op     -> let c_out  = msbW8 x
                                             result = shlW8 x 1
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            SlaOp     -> let c_out  = msbW8 x
                                             result = shlW8 x c_in
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            SlxOp     -> let c_out  = msbW8 x
                                             result = shlW8 x (lsbW8 x)
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            Sr0Op     -> let c_out  = lsbW8 x
                                             result = shrW8 0 x
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            Sr1Op     -> let c_out  = lsbW8 x
                                             result = shrW8 1 x
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            SraOp     -> let c_out  = lsbW8 x
                                             result = shrW8 c_in x
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)
                            SrxOp     -> let c_out  = lsbW8 x
                                             result = shrW8 (msbW8 x) x
                                             z_out  = if result==0 then 1 else 0
                                         in (result,z_out,c_out)

decode :: IWord -> Instruction
decode iword = case (decodeBinop iword,decodeBitop iword,decodeBranch iword,decodeReturn iword) of
                 (Just op,_,_,_)            -> BinopInstr op x rand
                 (_,Just op,_,_)            -> BinopInstr op x (ConstOperand (W8 0 0 0 0 0 0 0 0))
                 (_,_,Just (isJump,cond),_) -> BranchInstr isJump cond a
                 (_,_,_,Just cond)          -> ReturnInstr cond
                 _                          -> case (b17,b16,b15,b14) of
                  (0,0,0,1) -> case b13 of
                                1 -> FetchInstr x rand
                                _ -> InputInstr x rand
                  (1,0,1,1) -> case b13 of
                                1 -> StoreInstr x rand
                                _ -> OutputInstr x rand
                  (1,1,1,0) -> ReturniInstr b0
                  (1,1,1,1) -> IEnableInstr b0
                  _         -> InvalidInstr
  where W18 b17 b16 b15 b14 b13 b12 b11 b10 b9 b8 b7 b6 b5 b4 b3 b2 b1 b0 = iword
        x = W4 b11 b10 b9 b8
        y = W4 b7 b6 b5 b4
        k = W8 b7 b6 b5 b4 b3 b2 b1 b0
        s = W6 b5 b4 b3 b2 b1 b0
        p = k
        a = W10 b9 b8 b7 b6 b5 b4 b3 b2 b1 b0
        rand = case b12 of
                1 -> RegOperand y
                _ -> ConstOperand k

        decodeBinop :: IWord -> Maybe Binop
        decodeBinop (W18 b17 b16 b15 b14 b13 _ _ _ _ _ _ _ _ _ _ _ _ _) =
          case (b17,b16,b15,b14,b13) of
            (0,1,1,0,b) -> Just (AddOp b)
            (0,0,1,0,1) -> Just AndOp
            (0,1,0,1,0) -> Just CompareOp
            (0,0,0,0,0) -> Just LoadOp
            (0,0,1,1,0) -> Just OrOp
            (0,1,1,1,b) -> Just (SubOp b)
            (0,1,0,0,1) -> Just TestOp
            (0,0,1,1,1) -> Just XorOp
            _           -> Nothing
        
        decodeBitop :: IWord -> Maybe Binop
        decodeBitop (W18 1 0 0 0 0 _ _ _ _ _ _ _ _ _ b3 b2 b1 b0) =
          case (b3,b2,b1,b0) of
           (0,0,1,0) -> Just RlOp
           (1,1,0,0) -> Just RrOp
           (0,1,1,0) -> Just Sl0Op
           (0,1,1,1) -> Just Sl1Op
           (0,0,0,0) -> Just SlaOp
           (0,1,0,0) -> Just SlxOp
           (1,1,1,0) -> Just Sr0Op
           (1,1,1,1) -> Just Sr1Op
           (1,0,0,0) -> Just SraOp
           (1,0,1,0) -> Just SrxOp
           _         -> Nothing
        decodeBitop _ =
          Nothing
        
        decodeCond :: (Bit,Bit,Bit) -> Maybe BranchCond
        decodeCond (0,0,0) = Just NoCond
        decodeCond (1,1,0) = Just CCond
        decodeCond (1,1,1) = Just NCCond
        decodeCond (1,0,1) = Just NZCond
        decodeCond (1,0,0) = Just ZCond
        decodeCond _       = Nothing
        
        decodeBranch :: IWord -> Maybe (Bit,BranchCond)
        decodeBranch (W18 1 1 0 isJump _ a b c _ _ _ _ _ _ _ _ _ _) =
          fmap (\ cond -> (isJump,cond)) (decodeCond (a,b,c))
        decodeBranch _ =
          Nothing
        
        decodeReturn :: IWord -> Maybe BranchCond
        decodeReturn (W18 1 0 1 0 _ a b c _ _ _ _ _ _ _ _ _ _) = decodeCond (a,b,c)
        decodeReturn _                                         = Nothing

getPC :: CPUM W10
getPC = undefined
putPC :: W10 -> CPUM ()
putPC = undefined
getZFlag :: CPUM Bit
getZFlag = undefined
getCFlag :: CPUM Bit
getCFlag = undefined
getIEFlag :: CPUM Bit
getIEFlag = undefined
putZFlag :: Bit -> CPUM ()
putZFlag = undefined
putCFlag :: Bit -> CPUM ()
putCFlag = undefined
putZSave :: Bit -> CPUM ()
putZSave = undefined
putCSave :: Bit -> CPUM ()
putCSave = undefined
putIEFlag :: Bit -> CPUM ()
putIEFlag = undefined

incrPC :: CPUM ()
incrPC = undefined
getSP :: CPUM W5
getSP = undefined
incrSP :: CPUM ()
incrSP = undefined
decrSP :: CPUM ()
decrSP = undefined

neg :: Bit -> Bit
neg 1 = 0
neg _ = 1

zeroOutput = Outputs { address_out       = 0,
                       port_id_out       = 0,
                       write_strobe_out  = 0,
                       out_port_out      = 0,
                       read_strobe_out   = 0,
                       interrupt_ack_out = 0,
                       reg_data_out      = 0,
                       reg_write_out     = 0,
                       reg_addr_out      = 0,
                       reg_addr2_out     = 0,
                       stk_data_out      = 0,
                       stk_addr_out      = 0,
                       stk_write_out     = 0,
                       sp_data_out       = 0,
                       sp_addr_out       = 0,
                       sp_write_out      = 0 }

evalCond cond = do z <- getZFlag
                   c <- getCFlag
                   case cond of
                     NoCond -> return 1
                     ZCond  -> return z
                     NZCond -> return (neg z)
                     CCond  -> return c
                     NCCond -> return (neg c)

loop i = case reset_in i of
          1 -> do putPC 0
                  putIEFlag 0
                  putZFlag 0
                  putCFlag 0
                  i <- signal zeroOutput
                  loop i
          _ -> do
            ie <- getIEFlag
            case (ie,interrupt_in i) of
             (1,1) -> do
               z <- getZFlag
               c <- getCFlag
               putZSave z
               putCSave c
               putIEFlag 0
               
               let target = 0x3ff

               pc <- getPC
               sp <- getSP
               putPC target
               incrSP
               
               i  <- signal (zeroOutput { address_out   = target,
                                          stk_addr_out  = sp,
                                          stk_data_out  = pc,
                                          stk_write_out = 1 })
               loop i
             _     -> case decode (instruction_in i) of
               BinopInstr o rx rand -> do incrPC
                                          i  <- signal (zeroOutput { reg_addr_out  = rx,
                                                                     reg_addr2_out = case rand of
                                                                                       ConstOperand _ -> 0
                                                                                       RegOperand rY  -> rY })
                                          z_in <- getZFlag
                                          c_in <- getCFlag
                                          let vx = reg_data_in i
                                              vy = case rand of
                                                     ConstOperand k -> k
                                                     _              -> reg_data2_in i
                                              (res,z_out,c_out) = doBinop o vx vy z_in c_in
                                          putZFlag z_out
                                          putCFlag c_out
                                          pc <- getPC
                                          i  <- signal (zeroOutput { address_out   = pc,
                                                                     reg_addr_out  = rx,
                                                                     reg_write_out = 1,
                                                                     reg_data_out  = res })
                                          loop i
               BranchInstr isJump cond target -> do takeBranch <- evalCond cond
                                                    case takeBranch of
                                                     0 -> do incrPC
                                                             pc <- getPC
                                                             i  <- signal (zeroOutput { address_out = pc })
                                                             loop i
                                                     _ -> case isJump of
                                                           1 -> do putPC target
                                                                   i <- signal (zeroOutput { address_out = target })
                                                                   loop i
                                                           _ -> do sp <- getSP
                                                                   incrSP
                                                                   pc <- getPC
                                                                   putPC target
                                                                   i  <- signal (zeroOutput { address_out   = target,
                                                                                              stk_addr_out  = sp,
                                                                                              stk_data_out  = pc,
                                                                                              stk_write_out = 1 })
                                                                   loop i
               ReturnInstr cond -> do takeBranch <- evalCond cond
                                      case takeBranch of
                                       0 -> do incrPC
                                               pc <- getPC
                                               i  <- signal (zeroOutput { address_out = pc })
                                               loop i
                                       _ -> do decrSP
                                               sp <- getSP
                                               i  <- signal (zeroOutput { stk_addr_out = sp })
                                               let target = stk_data_in i + 1
                                               putPC target
                                               i  <- signal (zeroOutput { address_out = target })
                                               loop i
               ReturniInstr enable -> do sp <- getSP
                                         i  <- signal (zeroOutput { stk_addr_out = sp })
                                         let target = stk_data_in i
                                         putPC target
                                         putIEFlag enable
                                         i  <- signal (zeroOutput { address_out = target })
                                         loop i
               IEnableInstr enable -> do incrPC
                                         putIEFlag enable
                                         pc <- getPC
                                         i  <- signal (zeroOutput { address_out = pc })
                                         loop i
               FetchInstr rx rand  -> do incrPC
                                         i  <- signal (zeroOutput { reg_addr_out = case rand of
                                                                                     ConstOperand _ -> 0
                                                                                     RegOperand ry  -> ry })
                                         let addr = case rand of
                                                      ConstOperand k -> k
                                                      RegOperand _   -> reg_data_in i
                                         i  <- signal (zeroOutput { sp_addr_out = w8ToW6 addr })
                                         pc <- getPC
                                         let v = sp_data_in i
                                         i  <- signal (zeroOutput { address_out   = pc,
                                                                    reg_addr_out  = rx,
                                                                    reg_data_out  = v,
                                                                    reg_write_out = 1 })
                                         loop i
               StoreInstr rx rand  -> do incrPC
                                         i <- signal (zeroOutput { reg_addr_out  = rx,
                                                                   reg_addr2_out = case rand of
                                                                                    ConstOperand _ -> 0
                                                                                    RegOperand ry  -> ry })
                                         let addr = case rand of
                                                      ConstOperand k -> k
                                                      RegOperand _   -> reg_data2_in i
                                             v    = reg_data_in i
                                         pc <- getPC
                                         i  <- signal (zeroOutput { address_out  = pc,
                                                                    sp_addr_out  = w8ToW6 addr,
                                                                    sp_data_out  = v,
                                                                    sp_write_out = 1 })
                                         loop i
               InputInstr rx rand  -> do incrPC
                                         i <- signal (zeroOutput { reg_addr_out = case rand of
                                                                                   ConstOperand _ -> 0
                                                                                   RegOperand ry  -> ry })
                                         let port = case rand of
                                                      ConstOperand k -> k
                                                      RegOperand _   -> reg_data_in i
                                         i  <- signal (zeroOutput { port_id_out     = port,
                                                                    read_strobe_out = 1 })
                                         let v = in_port_in i
                                         pc <- getPC
                                         i  <- signal (zeroOutput { address_out   = pc,
                                                                    reg_addr_out  = rx,
                                                                    reg_data_out  = v,
                                                                    reg_write_out = 1 })
                                         loop i
               OutputInstr rx rand -> do incrPC
                                         i <- signal (zeroOutput { reg_addr_out  = rx,
                                                                   reg_addr2_out = case rand of
                                                                                    ConstOperand _ -> 0
                                                                                    RegOperand ry  -> ry })
                                         let port = case rand of
                                                      ConstOperand k -> k
                                                      RegOperand _   -> reg_data2_in i
                                             v    = reg_data_in i
                                         pc <- getPC
                                         i <- signal (zeroOutput { address_out      = pc,
                                                                   port_id_out      = port,
                                                                   write_strobe_out = 1,
                                                                   out_port_out     = v})
                                         loop i
               InvalidInstr        -> do incrPC
                                         pc <- getPC
                                         i  <- signal (zeroOutput { address_out = pc })
                                         loop i

w8ToW6 :: W8 -> W6
w8ToW6 (W8 _ _ b5 b4 b3 b2 b1 b0) = W6 b5 b4 b3 b2 b1 b0

-------------
-------------
---       ---
--- Tests ---
---       ---
-------------
-------------

---------------------------
--- Instruction decoder ---
---------------------------

-- Baseline implementation of the instruction decoder. Not very efficient, but
-- it's directly from Table D-1 of the PicoBlaze user guide.
decodeFromTable :: IWord -> Instruction
decodeFromTable (W18 b17 b16 b15 b14 b13 b12 b11 b10 b9 b8 b7 b6 b5 b4 b3 b2 b1 b0) =
  case (b17,b16,b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1,b0) of
    (0,1,1,0,0,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr (AddOp 0) (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,1,0,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr (AddOp 0) (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,1,1,0,1,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr (AddOp 1) (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,1,0,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr (AddOp 1) (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,0,1,0,1,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr AndOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,0,1,0,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr AndOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (1,1,0,0,0,0,0,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 0 NoCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,0,0,1,1,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 0 CCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,0,0,1,1,1,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 0 NCCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,0,0,1,0,1,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 0 NZCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,0,0,1,0,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 0 ZCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (0,1,0,1,0,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr CompareOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,0,1,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr CompareOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0)             -> IEnableInstr 0
    (1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1)             -> IEnableInstr 1
    (0,0,0,1,1,0,x3,x2,x1,x0,0,0,s5,s4,s3,s2,s1,s0)   -> FetchInstr (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 s5 s4 s3 s2 s1 s0))
    (0,0,0,1,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> FetchInstr (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,0,0,1,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> InputInstr (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,0,0,1,0,0,x3,x2,x1,x0,p7,p6,p5,p4,p3,p2,p1,p0) -> InputInstr (W4 x3 x2 x1 x0) (ConstOperand (W8 p7 p6 p5 p4 p3 p2 p1 p0))
    (1,1,0,1,0,0,0,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 1 NoCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,1,0,1,1,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 1 CCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,1,0,1,1,1,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 1 NCCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,1,0,1,0,1,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 1 NZCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (1,1,0,1,0,1,0,0,a9,a8,a7,a6,a5,a4,a3,a2,a1,a0)   -> BranchInstr 1 ZCond (W10 a9 a8 a7 a6 a5 a4 a3 a2 a1 a0)
    (0,0,0,0,0,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr LoadOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,0,0,0,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr LoadOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,0,1,1,0,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr OrOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,0,1,1,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr OrOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (1,0,1,1,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> OutputInstr (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (1,0,1,1,0,0,x3,x2,x1,x0,p7,p6,p5,p4,p3,p2,p1,p0) -> OutputInstr (W4 x3 x2 x1 x0) (ConstOperand (W8 p7 p6 p5 p4 p3 p2 p1 p0))
    (1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0)             -> ReturnInstr NoCond
    (1,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0)             -> ReturnInstr CCond
    (1,0,1,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0)             -> ReturnInstr NCCond
    (1,0,1,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0)             -> ReturnInstr NZCond
    (1,0,1,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0)             -> ReturnInstr ZCond
    (1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)             -> ReturniInstr 0
    (1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1)             -> ReturniInstr 1
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,0,0,1,0)         -> BinopInstr RlOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,1,1,0,0)         -> BinopInstr RrOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,0,1,1,0)         -> BinopInstr Sl0Op (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,0,1,1,1)         -> BinopInstr Sl1Op (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,0,0,0,0)         -> BinopInstr SlaOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,0,1,0,0)         -> BinopInstr SlxOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,1,1,1,0)         -> BinopInstr Sr0Op (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,1,1,1,1)         -> BinopInstr Sr1Op (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,1,0,0,0)         -> BinopInstr SraOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,0,0,0,0,x3,x2,x1,x0,0,0,0,0,1,0,1,0)         -> BinopInstr SrxOp (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 0 0 0 0 0 0))
    (1,0,1,1,1,0,x3,x2,x1,x0,0,0,s5,s4,s3,s2,s1,s0)   -> StoreInstr (W4 x3 x2 x1 x0) (ConstOperand (W8 0 0 s5 s4 s3 s2 s1 s0))
    (1,0,1,1,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> StoreInstr (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,1,1,1,0,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr (SubOp 0) (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,1,1,0,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr (SubOp 0) (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,1,1,1,1,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr (SubOp 1) (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,1,1,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr (SubOp 1) (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,1,0,0,1,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr TestOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,1,0,0,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr TestOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    (0,0,1,1,1,0,x3,x2,x1,x0,k7,k6,k5,k4,k3,k2,k1,k0) -> BinopInstr XorOp (W4 x3 x2 x1 x0) (ConstOperand (W8 k7 k6 k5 k4 k3 k2 k1 k0))
    (0,0,1,1,1,1,x3,x2,x1,x0,y3,y2,y1,y0,0,0,0,0)     -> BinopInstr XorOp (W4 x3 x2 x1 x0) (RegOperand (W4 y3 y2 y1 y0))
    _                                                 -> InvalidInstr

-- The property we want to test. Note that decodeFromTable is strictly less
-- forgiving than decode in that it will sometimes consider an instruction word
-- invalid where decode considers it valid. This is okay, because invalid
-- instruction behavior is seemingly undefined in PicoBlaze; the important
-- thing is that they match when decodeFromTable returns a *valid* instruction.
--
-- This property is suitable for use with QuickCheck.
prop_decode iw = d == InvalidInstr || d == decode iw
  where d = decodeFromTable iw

-- Generates an exhaustive table of test results. An element is of the form
-- (b,(iw,d1,d2)) where b is a boolean indicating whether the test passed,
-- iw is the instruction word for the test, d1 is the result from "decode",
-- and d2 is the result from "decodeFromTable".
exhaustive_decode = map (\ iw -> (prop_decode iw,(iw,decode iw,decodeFromTable iw))) [minBound..maxBound]

-- Picks out the failed test cases from exhaustive_decode. This should evaluate
-- to the empty list.
check_exhaustive_decode = filter ((==False) . fst) exhaustive_decode

-- A little spot check on decodeFromTable: how many instructions are valid
-- according to the spec? The decodeFromTable function should produce
-- something other than InvalidInstr for exactly that many distinct instruction
-- words.
how_many_valid =
   hmArith*3  -- add,addcy,and
 + hmBranch*5 -- call
 + hmArith    -- compare
 + 2          -- en/dis interrupts
 + hmMem      -- fetch
 + hmArith    -- input
 + hmBranch*5 -- jump
 + hmArith*3  -- load,or,output
 + 7          -- various returns
 + hmBit*10   -- rl,rr,sl0,sl1,sla,slx,sr0,sr1,sra,srx
 + hmMem      -- store
 + hmArith*4  -- sub,subcy,test,xor
   where hmArith  = 2^12 + 2^8 -- xxxxkkkkkkkk or xxxxyyyy
         hmBranch = 2^10       -- aaaaaaaaaa
         hmMem    = 2^10 + 2^8 -- xxxxssssss or xxxxyyyy
         hmBit    = 2^4        -- xxxx

correct_number_valid = how_many_valid == (length $ filter ((/=InvalidInstr) . decodeFromTable) [minBound..maxBound])

-------------------
--- Boilerplate ---
-------------------

-- Bit
instance Show Bit where
  show Zero = "0"
  show One  = "1"
  
boolToBit True  = One
boolToBit False = Zero

bitToNum :: Num a => Bit -> a
bitToNum Zero = 0
bitToNum One  = 1

instance Num Bit where
  fromInteger n = boolToBit $ testBit n 0
  -- Assume two's complement here.
  n + m  = fromInteger (bitToNum n + bitToNum m)
  n * m  = fromInteger (bitToNum n * bitToNum m)
  abs    = id
  signum = id
  negate = id

instance Arbitrary Bit where
  arbitrary = frequency [(1,return Zero),(1,return One)]

andBit 1 x = x
andBit _ _ = 0

orBit 0 x = x
orBit _ _ = 1

xorBit 0 0 = 0
xorBit 0 1 = 1
xorBit 1 0 = 1
xorBit _ _ = 0

-- W18
instance Show W18 where
  show = show . w18ToInt

instance Arbitrary W18 where
  arbitrary = W18 <$> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary
                  <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary
                  <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary

intToW18 :: Int -> W18
intToW18 n = W18
             (n `tb` 17)
             (n `tb` 16)
             (n `tb` 15)
             (n `tb` 14)
             (n `tb` 13)
             (n `tb` 12)
             (n `tb` 11)
             (n `tb` 10)
             (n `tb` 9)
             (n `tb` 8)
             (n `tb` 7)
             (n `tb` 6)
             (n `tb` 5)
             (n `tb` 4)
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w18ToInt (W18 b17 b16 b15 b14 b13 b12 b11 b10 b9 b8 b7 b6 b5 b4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToInt [b17,b16,b15,b14,b13,b12,b11,b10,b9,b8,b7,b6,b5,b4,b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2
        bitToInt Zero = 0
        bitToInt One  = 1

instance Bounded W18 where
  minBound = intToW18 0
  maxBound = intToW18 262143

instance Enum W18 where
  succ x = intToW18 (w18ToInt x + 1)
  toEnum = intToW18
  fromEnum = w18ToInt

-- W10
instance Num W10 where
  fromInteger = bitsToW10
  -- Assume two's complement here.
  n + m  = fromInteger (w10ToNum n + w10ToNum m)
  n * m  = fromInteger (w10ToNum n * w10ToNum m)
  abs    = fromInteger . (abs :: Integer -> Integer) . w10ToNum
  signum = fromInteger. (signum :: Integer -> Integer) . w10ToNum
  negate = fromInteger . (negate :: Integer -> Integer) . w10ToNum

bitsToW10 :: Bits a => a -> W10
bitsToW10 n = W10
             (n `tb` 9)
             (n `tb` 8)
             (n `tb` 7)
             (n `tb` 6)
             (n `tb` 5)
             (n `tb` 4)
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w10ToNum :: Num a => W10 -> a
w10ToNum (W10 b9 b8 b7 b6 b5 b4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToNum [b9,b8,b7,b6,b5,b4,b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2

-- W8
instance Num W8 where
  fromInteger = bitsToW8
  -- Assume two's complement here.
  n + m  = fromInteger (w8ToNum n + w8ToNum m)
  n * m  = fromInteger (w8ToNum n * w8ToNum m)
  abs    = fromInteger . (abs :: Integer -> Integer) . w8ToNum
  signum = fromInteger. (signum :: Integer -> Integer) . w8ToNum
  negate = fromInteger . (negate :: Integer -> Integer) . w8ToNum

bitsToW8 :: Bits a => a -> W8
bitsToW8 n = W8
             (n `tb` 7)
             (n `tb` 6)
             (n `tb` 5)
             (n `tb` 4)
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w8ToNum :: Num a => W8 -> a
w8ToNum (W8 b7 b6 b5 b4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToNum [b7,b6,b5,b4,b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2

-- W6
instance Num W6 where
  fromInteger = bitsToW6
  -- Assume two's complement here.
  n + m  = fromInteger (w6ToNum n + w6ToNum m)
  n * m  = fromInteger (w6ToNum n * w6ToNum m)
  abs    = fromInteger . (abs :: Integer -> Integer) . w6ToNum
  signum = fromInteger. (signum :: Integer -> Integer) . w6ToNum
  negate = fromInteger . (negate :: Integer -> Integer) . w6ToNum

bitsToW6 :: Bits a => a -> W6
bitsToW6 n = W6
             (n `tb` 5)
             (n `tb` 4)
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w6ToNum :: Num a => W6 -> a
w6ToNum (W6 b5 b4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToNum [b5,b4,b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2

-- W5
instance Num W5 where
  fromInteger = bitsToW5
  -- Assume two's complement here.
  n + m  = fromInteger (w5ToNum n + w5ToNum m)
  n * m  = fromInteger (w5ToNum n * w5ToNum m)
  abs    = fromInteger . (abs :: Integer -> Integer) . w5ToNum
  signum = fromInteger. (signum :: Integer -> Integer) . w5ToNum
  negate = fromInteger . (negate :: Integer -> Integer) . w5ToNum

bitsToW5 :: Bits a => a -> W5
bitsToW5 n = W5
             (n `tb` 4)
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w5ToNum :: Num a => W5 -> a
w5ToNum (W5 b4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToNum [b4,b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2

-- W4
instance Num W4 where
  fromInteger = bitsToW4
  -- Assume two's complement here.
  n + m  = fromInteger (w4ToNum n + w4ToNum m)
  n * m  = fromInteger (w4ToNum n * w4ToNum m)
  abs    = fromInteger . (abs :: Integer -> Integer) . w4ToNum
  signum = fromInteger. (signum :: Integer -> Integer) . w4ToNum
  negate = fromInteger . (negate :: Integer -> Integer) . w4ToNum

bitsToW4 :: Bits a => a -> W4
bitsToW4 n = W4
             (n `tb` 3)
             (n `tb` 2)
             (n `tb` 1)
             (n `tb` 0)
  where n `tb` k = boolToBit (n `testBit` k)
        boolToBit True  = 1
        boolToBit False = 0

w4ToNum :: Num a => W4 -> a
w4ToNum (W4 b3 b2 b1 b0) =
  sum (zipWith (*) (reverse (map bitToNum [b3,b2,b1,b0])) pows2)
  where pows2 = 1 : map (*2) pows2

