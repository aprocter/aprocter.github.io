module Harness where

import Control.Monad.Resumption.Reactive
import Control.Monad.State
import Control.Monad.Identity
import PicoBlaze

type ReactT = ReacT
next        = deReacT

-- Core monad
type CoreR = ReactT Inputs Outputs CoreK 
type CoreK = StateT CPUState Identity

-- System monad
type SharedReg = W8
type K         = (StateT SharedReg
                  (StateT CPUState
                   (StateT CPUState Identity)))
type SysM      = ReactT (Inputs,Inputs) (Outputs,Outputs) K

liftKL :: CoreK a -> K a
liftKL = lift . lift

liftKH :: CoreK a -> K a
liftKH phi = lift (do s <- get
                      let (a,s') = runIdentity (runStateT phi s)
                      put s'
                      return a)

harness :: CoreR a -> CoreR b -> SysM (Either a b)
harness (ReacT lo) (ReacT hi) =
    (lift . liftKL) lo >>= \ r_lo ->
    (lift . liftKH) hi >>= \ r_hi ->
    case (r_lo,r_hi) of
         (Left a,_) -> return (Left a)
         (_,Left b) -> return (Right b)
         (Right (o_lo,k_lo),Right (o_hi,k_hi)) ->
              signal (o_lo,o_hi)    >>= \ (i_lo,i_hi) ->
              checkHiPort i_hi o_hi >>= \ i_hi' ->
              checkLoPort o_lo      >>
              harness (k_lo i_lo) (k_hi i_hi')

checkHiPort :: Inputs  ->
               Outputs ->
               SysM Inputs
checkHiPort i_hi o_hi = lift (chkHPrt i_hi o_hi)

chkHPrt :: Inputs -> Outputs -> K Inputs
chkHPrt i_hi o_hi =
   case (port_id_out o_hi,read_strobe_out o_hi) of
        -- Check for register read.
        (W8 One One One One One One One One,One) ->
           get >>= \ v -> return (i_hi { in_port_in = v })
        _                                        ->
           return i_hi

checkLoPort :: Outputs -> SysM ()
checkLoPort o_lo = lift (chkLPrt o_lo)

chkLPrt :: Outputs -> K ()
chkLPrt o_lo =
  case (port_id_out o_lo,write_strobe_out o_lo) of
       -- Check for register write.
       (W8 One One One One One One One One,One) ->
         put (out_port_out o_lo)
       _                                        ->
         return ()

------------------------------------------
------------------------------------------
--- Purely proof-related stuff follows ---
------------------------------------------
------------------------------------------

--
-- Lifts "across" a state transformer
--
generalize :: StateT s Identity a -> StateT s (StateT s' Identity) a
generalize (StateT phi) = StateT $ return . runIdentity . phi

{-
liftLo :: StateT lo Identity a ->
          ReacT (Inputs,Inputs)
                (Outputs,Outputs)
                (StateT SharedReg
                   (StateT hi
                       (StateT lo Identity))) a
-}
liftLo phi = lift . liftKL $ phi

liftHi :: StateT hi Identity a ->
          ReacT (Inputs,Inputs)
                (Outputs,Outputs)
                (StateT SharedReg
                   (StateT hi
                      (StateT lo Identity))) a
liftHi phi = lift . lift . generalize $ phi

{-
pull :: Monad m =>
        [ol] ->
        [i]  ->
        ReacT i (ol, oh) m a -> m [ol]
-}
pull :: [Outputs] -> [(Inputs,Inputs)] -> ReacT (Inputs,Inputs) (Outputs,Outputs) K [Outputs] -> K [Outputs]
pull os [] _       = return os
pull os (i:is) phi = next phi >>= \ (Right (o,k)) ->
                     pull (os ++ [fst o]) is (k i)

skip :: Outputs -> Inputs -> ReacT Inputs Outputs K a
skip o i = ReacT (return (Right (o,skip o)))
         
maskH :: K ()
maskH = liftKH (update (const s0))
   where s0 = undefined

update :: Monad m => (s -> s) -> StateT s m ()
update f = StateT (\ s -> return ((),f s))
