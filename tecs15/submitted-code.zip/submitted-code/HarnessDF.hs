module HarnessDF (harness) where

import Control.Monad.Resumption.Reactive
import Control.Monad.State
import Control.Monad.Identity
import PicoBlazeDF

type ReactT = ReacT
--next        = deReacT

-- Core monad
--type CoreR = ReactT Inputs Outputs CoreK 
type CoreK = StateT CPUState Identity

-- System monad
type SharedReg = W8
type K         = (StateT SharedReg
                  (StateT CPUState
                   (StateT CPUState Identity)))
type SysM      = ReactT (Inputs,Inputs) (Outputs,Outputs) K

liftKL :: CoreK a -> K a
liftKL phi = lift (lift phi)

liftKH :: CoreK a -> K a
liftKH phi = lift (do s <- get
                      let (a,s') = runIdentity (runStateT phi s)
                      put s'
                      return a)

--getShared :: ReacT (Inputs, Inputs) (Outputs, Outputs) K W8
--getShared = lift get
--putShared :: W8 ->
--             ReacT (Inputs, Inputs) (Outputs, Outputs) K ()
--putShared = lift . put

--pull :: Monad m => [o] -> [i] -> ReactT i o m a -> m [o]
--pull os [] _       = return os
--pull os (i:is) phi = next phi >>= \ (Right (o,k)) ->
--                     pull (os ++ [o]) is (k i)

harness :: Kont -> Kont -> SysM ()
harness k_lo k_hi =
    signal (zeroOutput,zeroOutput) >>= \ (i_lo,i_hi) ->
    loop i_lo i_hi k_lo k_hi

loop :: Inputs -> Inputs -> Kont -> Kont -> SysM ()
loop i_lo i_hi k_lo k_hi =
    lift (liftKL (doKont k_lo i_lo)) >>= \ (o_lo,k'_lo) ->
    lift (liftKH (doKont k_hi i_hi)) >>= \ (o_hi,k'_hi) ->
    signal (o_lo,o_hi)               >>= \ (i'_lo,i'_hi) ->
    checkHiPort i'_hi o_hi           >>= \ i''_hi ->
    checkLoPort o_lo                 >>
    loop i'_lo i''_hi k'_lo k'_hi

checkHiPort :: Inputs  ->
               Outputs ->
               SysM Inputs
checkHiPort i_hi o_hi = lift (chkHPrt i_hi o_hi)

chkHPrt :: Monad m => Inputs -> Outputs -> (StateT W8 m) Inputs
chkHPrt i_hi o_hi =
   case (port_id_out o_hi,read_strobe_out o_hi) of
        -- Check for register read.
        (W8 One One One One One One One One,One) ->
           get >>= \ v -> return (i_hi { in_port_in = v })
        _                                        ->
           return i_hi


checkLoPort :: Outputs -> SysM ()
checkLoPort o_lo = lift (chkLPrt o_lo)

chkLPrt :: Monad m => Outputs -> StateT W8 m ()
chkLPrt o_lo =
  case (port_id_out o_lo,write_strobe_out o_lo) of
       -- Check for register write.
       (W8 One One One One One One One One,One) ->
         put (out_port_out o_lo)
       _                                        ->
         return ()


--skipHi :: Outputs -> CoreR a
--skipHi o =  signal o >> skipHi o

--update :: Monad m => (s -> s) -> StateT s m ()
--update f = StateT (\ s -> return ((),f s))

