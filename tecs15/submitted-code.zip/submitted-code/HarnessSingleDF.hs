--
-- The single-core harness, defunctionalized.
--
module HarnessSingleDF where

import Control.Monad.Resumption.Reactive
import Control.Monad.State
import Control.Monad.Identity
import PicoBlaze

-- Core monad
type CoreR = ReacT Inputs Outputs CoreK 
type CoreK = StateT CPUState Identity

-- System monad
type K           = StateT CPUState
                     (StateT CPUState Identity)
type SysM        = ReacT (Either Inputs Inputs) (Either Outputs Outputs) K

liftKL :: CoreK a -> K a
liftKL = lift

liftKH :: CoreK a -> K a
liftKH phi = lift (do s <- get
                      let (a,s') = runIdentity (runStateT phi s)
                      put s'
                      return a)

harness :: Either Inputs Inputs -> CoreR a -> CoreR b -> SysM (Either a b)
harness (Left i) lo hi  = do r <- lift $ liftKL (deReacT lo)
                             case r of
                               Left a      -> return (Left a)
                               Right (o,k) -> do i' <- signal (Left o)
                                                 harness i' (k i) hi
harness (Right i) lo hi = do r <- lift $ liftKH (deReacT hi)
                             case r of
                               Left a      -> return (Right a)
                               Right (o,k) -> do i' <- signal (Right o)
                                                 harness i' lo (k i)
